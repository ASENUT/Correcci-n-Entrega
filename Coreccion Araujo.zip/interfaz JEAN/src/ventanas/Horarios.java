/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import Datos.DCitas;
import Logico.LCitas;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.TextField;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alumnos
 */
public class Horarios extends javax.swing.JFrame {
    LCitas citas= new LCitas();
    DCitas d=new DCitas();
    Logico.Conexion c = new Logico.Conexion();
    PreparedStatement cmd;  
    ResultSet rs;
    String HoraCita;
    String FechaCita;
    String Cliente;
    String TipoCita;
    String accion ="";//Para saber que accion realizar, guardar, eliminar, editar
    public Horarios() {
        PreparedStatement cmd;  
        ResultSet rs;
        initComponents();
        this.setLocationRelativeTo(null);
        sacartexto();
        
    }

    private void CargarTabla(){
        try {
            DefaultTableModel modelo;
            LCitas func=new LCitas();
            modelo =func.CargarTabla();
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void Mostrar(String buscar){
        try {
            DefaultTableModel modelo;
            LCitas func=new LCitas();
            modelo =func.mostrarh(buscar);
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void sacartexto(){
        FechaCita=d.getFechaCita();
        HoraCita=d.getHoraCita();
        
    }
       
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Lista_Cita = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        txtfBuscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnImprimir = new javax.swing.JMenu();
        btnEditar = new javax.swing.JMenu();
        btnActualizar = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Lista_Cita.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "COD Horario", "Hora Cita", "Fecha Cita"
            }
        ));
        jScrollPane1.setViewportView(Lista_Cita);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 620, 150));

        btnBuscar.setText("Buscar");
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        txtfBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(txtfBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 210, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 230));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        btnImprimir.setText("Imprirmir");
        btnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnImprimirMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnImprimir);

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Edit.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEditar);

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnActualizarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnActualizar);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        Citas c = new Citas();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu5MouseClicked
    
    private void btnEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseClicked
        // TODO add your handling code here:
        String busqueda=txtfBuscar.getText();
        int cod=citas.mostrarCod(busqueda);
        EditarHorario eh=new EditarHorario();
        eh.setCod(cod);
        eh.setVisible(true);
        this.dispose();
   
    }//GEN-LAST:event_btnEditarMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       CargarTabla();
    }//GEN-LAST:event_formWindowOpened

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        String busqueda=txtfBuscar.getText();
        Mostrar(busqueda);
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnActualizarMouseClicked
        CargarTabla();
        
    }//GEN-LAST:event_btnActualizarMouseClicked

    private void txtfBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfBuscarActionPerformed

    private void btnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImprimirMouseClicked
        PrintJob imprime = getToolkit().getPrintJob(this, evt.getClass().getName(), null);
        if (imprime != null) {
            Graphics pag = imprime.getGraphics();
            if (pag != null) {
                paint(pag); //pinta todo los objetos de la ventana mostrada
                pag.dispose();
            }
        } else {
            //JOptionPane.showMessageDialog(null, “no se imprimo nada”, “imprimir”, JOptionPane.INFORMATION_MESSAGE );
            imprime.end();
        }
        imprime.end();        // TODO add your handling code here:
    }//GEN-LAST:event_btnImprimirMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Horarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Lista_Cita;
    private javax.swing.JMenu btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JMenu btnEditar;
    private javax.swing.JMenu btnImprimir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtfBuscar;
    // End of variables declaration//GEN-END:variables
}
